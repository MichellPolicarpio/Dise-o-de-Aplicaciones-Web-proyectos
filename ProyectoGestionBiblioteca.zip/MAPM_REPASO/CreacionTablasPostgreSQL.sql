-- Policarpio Moran Michell Alexis - zS21002379 - Diseño de Aplicaciones Web
CREATE DATABASE bdbiblioteca;


CREATE TABLE libros(
	id serial PRIMARY KEY,
	titulo varchar(40),
	autor varchar(30),
	anio int
);

-- Crear la tabla clientes
CREATE TABLE clientes (
    id serial PRIMARY KEY,
    nombre varchar(20) UNIQUE,
    apellidoP varchar(15),
    apellidoM varchar(15)
);

-- Crear la tabla pedidos
CREATE TABLE pedidos (
    id SERIAL PRIMARY KEY,
    id_cliente INT REFERENCES clientes(id),
    id_libro INT REFERENCES libros(id),
    fecha_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);



-- (OPCION DE INSERTAR) Inserción de los datos
INSERT INTO libros (titulo, autor, anio) VALUES
('Python para todos', 'Raúl Gonzalez Duque','2016'),
('Programacion en c++', 'Luis Joyanes Aguilar','2005'),
('Programacion en C', 'Luis Joyanes Aguilar','2005'),
('Economia en una leccion', 'Henry Hazlitt','1946'),
('La virtud del egoismo', 'Ayn Rand','1943'),
('Una revolucion para España', 'Juan Ramon Rallo', '2015');



-- (OPCION MOSTRAR) Consulta de todos los datos dentro de la tabla 
SELECT * FROM libros;

-- Insertar datos en la tabla clientes
INSERT INTO clientes (nombre, apellidoP, apellidoM) VALUES
('Michell', 'Policarpio', 'Moran'),
('Miguel', 'Quintero', 'Ortiz'),
('Yuliana', 'Berumen', 'Diaz'),
('Isabella', 'Coria', 'Juarez'),
('Cesar', 'Garcia', 'Garcia'),
('Diana', 'Ceron', 'Marin');

-- Mostrar datos de la tabla clientes
SELECT * FROM clientes;

-- Insertar datos en la tabla pedidos
INSERT INTO pedidos (id_cliente, id_libro) VALUES (1, 2);
INSERT INTO pedidos (id_cliente, id_libro) VALUES (2, 3);
INSERT INTO pedidos (id_cliente, id_libro) VALUES (4, 5);
INSERT INTO pedidos (id_cliente, id_libro) VALUES (3, 1);

-- Mostrar datos de la tabla pedidos
SELECT * FROM pedidos;