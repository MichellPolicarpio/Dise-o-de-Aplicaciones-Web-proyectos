package com.mycompany.gestionbiblioteca;

import java.awt.HeadlessException;
import java.sql.CallableStatement;
import javax.swing.JTextField;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

/**
     * 
 * @author Michell Alexis Policarpio Moran - zs21002379 - Diseño de APlicaciones Web NRC: 17479
 */

public class Pedidos {

    int id;
    int id_cliente;
    int id_libro;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdCliente() {
        return id_cliente;
    }

    public void setIdCliente(int idCliente) {
        this.id_cliente = idCliente;
    }

    public int getIdLibro() {
        return id_libro;
    }

    public void setIdLibro(int idLibro) {
        this.id_libro = idLibro;
    }

public void MostrarPedidos(JTable paramTablaPedidos) {
    Cconexion objetoConexion = new Cconexion();
    DefaultTableModel modelo = new DefaultTableModel();
    String sql = "SELECT p.id AS id_pedido, c.id AS id_cliente, c.nombre AS nombre_cliente, c.apellidoP AS apellido_cliente, l.titulo AS libro_pedido, TO_CHAR(p.fecha_pedido, 'YYYY-MM-DD HH24:MI') AS fecha_pedido " +
             "FROM pedidos p " +
             "JOIN clientes c ON p.id_cliente = c.id " +
             "JOIN libros l ON p.id_libro = l.id;";

    modelo.addColumn("ID Pedido");
    modelo.addColumn("ID Cliente");
    modelo.addColumn("Nombre Cliente");
    modelo.addColumn("Apellido Cliente");
    modelo.addColumn("Libro Pedido");
    modelo.addColumn("Fecha Pedido");

    paramTablaPedidos.setModel(modelo);
    paramTablaPedidos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    Statement st;

    try {
        st = objetoConexion.establecerConexion().createStatement();
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            modelo.addRow(new Object[]{
                rs.getInt("id_pedido"),
                rs.getInt("id_cliente"),
                rs.getString("nombre_cliente"),
                rs.getString("apellido_cliente"),
                rs.getString("libro_pedido"),
                rs.getString("fecha_pedido")
            });
        }
        paramTablaPedidos.setModel(modelo);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error: " + e.toString());
    }
}

public void InsertarPedido(int idCliente, int idLibro) {
    // Obtener el ID del cliente y el ID del libro de los campos de texto
    // int idCliente = Integer.parseInt(paramIdCliente.getText());
    // int idLibro = Integer.parseInt(paramIdLibro.getText());
    
    // Imprimir los valores obtenidos de los campos de texto para depuración
    System.out.println("ID Cliente: " + idCliente);
    System.out.println("ID Libro: " + idLibro);
    
    // Inicializar la conexión a la base de datos
    Cconexion objetoConexion = new Cconexion();
    
    // Preparar la consulta SQL para insertar el nuevo pedido
    String consulta = "INSERT INTO pedidos (id_cliente, id_libro) VALUES (?, ?);";
    
    try {
        // Preparar la llamada al procedimiento almacenado
        CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
        
        // Establecer los parámetros en la consulta
        cs.setInt(1, idCliente);
        cs.setInt(2, idLibro);
        
        // Ejecutar la consulta
        cs.execute();
        
        // Mostrar un mensaje de éxito
        JOptionPane.showMessageDialog(null, "Se insertó correctamente el pedido.");
        
        // No necesitamos actualizar la tabla de pedidos aquí
        
    } catch (Exception e) {
        // Mostrar un mensaje de error si ocurre una excepción
        JOptionPane.showMessageDialog(null, "Error al insertar el pedido: " + e.toString());
    }
}

    public void SeleccionarPedido(JTable paramTablaPedidos, JTextField paramIdCliente, JTextField paramIdLibro) {
        try {
            int fila = paramTablaPedidos.getSelectedRow();

            if (fila >= 0) {
                // Obtener los valores de la fila seleccionada en la tabla
                Object idCliente = paramTablaPedidos.getValueAt(fila, 1);
                Object idLibro = paramTablaPedidos.getValueAt(fila, 0); // Ajuste aquí a la columna que contiene el ID del libro

                // Mostrar valores obtenidos para depuración
                System.out.println("ID Cliente: " + idCliente);
                System.out.println("ID Libro: " + idLibro);

                // Establecer los valores en los campos de texto
                paramIdCliente.setText(idCliente.toString());
                paramIdLibro.setText(idLibro.toString());
            } else {
                JOptionPane.showMessageDialog(null, "Por favor, seleccione una fila.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error:" + e.toString());
        }
    }

    public void ModificarPedido(JTable paramTablaPedidos, JTextField paramId, JTextField paramIdCliente, JTextField paramNombreLibro) {

        setId(Integer.parseInt(paramId.getText()));
        setIdCliente(Integer.parseInt(paramIdCliente.getText()));
        setIdLibro(Integer.parseInt(paramNombreLibro.getText()));

        Cconexion objetoConexion = new Cconexion();

        String consulta = "UPDATE pedidos SET id_cliente = ?, id_libro = ? WHERE pedidos.id=?;";

        try {

            CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
            cs.setInt(1, getIdCliente());
            cs.setInt(2, getIdLibro());
            cs.setInt(3, getId());

            cs.execute();

            JOptionPane.showMessageDialog(null, "Se modificó correctamente");

            MostrarPedidos(paramTablaPedidos);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error:" + e.toString());
        }

    }
   

    public void EliminarPedido(JTable paramTablaPedidos, int idCliente, int idPedido) {
    Cconexion objetoConexion = new Cconexion();
    String consulta = "DELETE FROM pedidos WHERE id_cliente = ? AND id = ?;";

    try {
        CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
        cs.setInt(1, idCliente);
        cs.setInt(2, idPedido); // Aquí se usa idPedido en lugar de idLibro

        cs.execute();

        JOptionPane.showMessageDialog(null, "Se eliminó correctamente");

        // Actualizar la tabla con los pedidos actualizados
        MostrarPedidos(paramTablaPedidos);

    } catch (HeadlessException | SQLException e) {
        JOptionPane.showMessageDialog(null, "Error:" + e.toString());
    }
}
    
    public void MostrarUsuarios(JTable paramTablaUsuarios) {
    Cconexion objetoConexion = new Cconexion();
    DefaultTableModel modelo = new DefaultTableModel();
    String sql = "SELECT id, nombre, apellidoP FROM clientes";

    modelo.addColumn("ID");
    modelo.addColumn("Nombre");
    modelo.addColumn("Apellido Paterno");

    paramTablaUsuarios.setModel(modelo);
    paramTablaUsuarios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    Statement st;

    try {
        st = objetoConexion.establecerConexion().createStatement();
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            modelo.addRow(new Object[]{
                rs.getInt("id"),
                rs.getString("nombre"),
                rs.getString("apellidoP")
            });
        }
        paramTablaUsuarios.setModel(modelo);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error: " + e.toString());
    }
}
    
    public void MostrarLibros(JTable paramTablaLibros) {
    Cconexion objetoConexion = new Cconexion();
    DefaultTableModel modelo = new DefaultTableModel();
    String sql = "SELECT id, titulo, autor FROM libros";

    modelo.addColumn("ID");
    modelo.addColumn("Título");
    modelo.addColumn("Autor");

    paramTablaLibros.setModel(modelo);
    paramTablaLibros.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    Statement st;

    try {
        st = objetoConexion.establecerConexion().createStatement();
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            modelo.addRow(new Object[]{
                rs.getInt("id"),
                rs.getString("titulo"),
                rs.getString("autor")
            });
        }
        paramTablaLibros.setModel(modelo);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error: " + e.toString());
    }
}

}

