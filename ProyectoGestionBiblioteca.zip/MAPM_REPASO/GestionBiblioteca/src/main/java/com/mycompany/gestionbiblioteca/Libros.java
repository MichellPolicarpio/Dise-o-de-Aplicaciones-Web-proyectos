package com.mycompany.gestionbiblioteca;

import java.sql.CallableStatement;
import javax.swing.JTextField;
import java.sql.ResultSet; 
import java.sql.Statement; 
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable; 
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

/**
 * // Atributos de la clase Libros para almacenar información de los libros
 * @author Michell Alexis Policarpio Moran - zs21002379 - Diseño de APlicaciones Web NRC: 17479
 */
public class Libros {
    
    int id;
    String titulo;
    String autor;
    int anio;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }
  
   // Método para mostrar todos los libros en una tabla
   public void MostrarLibros (JTable paramTablaTotalLibros){
   
       Cconexion objetoConexion = new Cconexion();
   
       DefaultTableModel modelo = new DefaultTableModel();
  
       String sql = "";
   
       modelo.addColumn("id");
       modelo.addColumn("titulo");
       modelo.addColumn("autor");
       modelo.addColumn("anio");
   
       paramTablaTotalLibros.setModel(modelo);
   
       // Establecer el modo de selección de la tabla
       paramTablaTotalLibros.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); 
   
       sql = "select * from libros;";
   
       String [] datos = new String[4];
   
       Statement st;
   
       try{
       
           st= objetoConexion.establecerConexion().createStatement();
       
           ResultSet rs = st.executeQuery(sql);
       
           while (rs.next()){
       
               datos[0] = rs.getString(1);
               datos[1] = rs.getString(2);
               datos[2] = rs.getString(3);
               datos[3] = rs.getString(4);
           
               modelo.addRow(datos);
           }
       
           // Llamada del metodo para ordenar por ordenamiento de burbuja alfabeticamente los libros
            ordenamientoBurbujaLibrosAlfabetico(modelo);
           paramTablaTotalLibros.setModel(modelo);
       
       } catch (Exception e){
       
           JOptionPane.showMessageDialog(null,"Error:"+e.toString());
    
       }
    
  }


    private void ordenamientoBurbujaLibrosAlfabetico(DefaultTableModel modelo) {
        for (int i = 0; i < modelo.getRowCount() - 1; i++) {
            for (int j = 0; j < modelo.getRowCount() - i - 1; j++) {
                // Compara los nombres de los libros 
                if (modelo.getValueAt(j, 1).toString().compareToIgnoreCase(modelo.getValueAt(j + 1, 1).toString()) > 0) {
                    // Intercambia filas
                    Object[] temp = new Object[modelo.getColumnCount()];
                    for (int k = 0; k < temp.length; k++) {
                        temp[k] = modelo.getValueAt(j, k);
                        modelo.setValueAt(modelo.getValueAt(j + 1, k), j, k);
                        modelo.setValueAt(temp[k], j + 1, k);
                    }
                }
            }
        }
    }
   
   

    
   // Método para insertar un nuevo libro en la base de datos
   public void InsertarLibros(JTable paramTablaTotalLibros, JTextField paramTitulo, JTextField paramAutor, JTextField paramAnio){
       
       setTitulo(paramTitulo.getText());
       setAutor(paramAutor.getText());
       setAnio(Integer.parseInt(paramAnio.getText())); 
       
       // Imprimir los valores obtenidos de los campos de texto
       System.out.println("Título: " + getTitulo());
       System.out.println("Autor: " + getAutor());
       System.out.println("Año: " + getAnio());
       
       Cconexion objetoConexion = new Cconexion();
       
       String consulta = "insert into libros (titulo, autor, anio) values(?,?,?);"; 
       
       try{
           
           CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
           cs.setString(1, getTitulo()); 
           cs.setString(2, getAutor()); 
           cs.setInt(3, getAnio()); 
           
           cs.execute();
           
           JOptionPane.showMessageDialog(null, "Se insertó correctamente");
           
           // Después de insertar, actualiza la tabla
           MostrarLibros(paramTablaTotalLibros);
           
       }catch(Exception e){
           JOptionPane.showMessageDialog(null, "Error:"+e.toString());
       }
   
   }
   
   // Método para seleccionar un libro de la tabla
    public void SeleccionarLibro(JTable paramTablaTotalLibros, JTextField paramId, JTextField paramTitulo, JTextField paramAutor, JTextField paramAnio){

           try{

               int fila = paramTablaTotalLibros.getSelectedRow();

               if(fila>=0){

                   paramId.setText(paramTablaTotalLibros.getValueAt(fila,0).toString());
                   paramTitulo.setText(paramTablaTotalLibros.getValueAt(fila,1).toString());
                   paramAutor.setText(paramTablaTotalLibros.getValueAt(fila,2).toString());
                   paramAnio.setText(paramTablaTotalLibros.getValueAt(fila,3).toString());
               }
               else{
                   JOptionPane.showMessageDialog(null, "Por favor, seleccione una fila.");
               }

           }catch(Exception e){
               JOptionPane.showMessageDialog(null, "Error:"+e.toString());
           }
       }

    // Método para modificar un libro existente en la base de datos
    public void ModificarLibro(JTable paramTablaTotalLibros, JTextField paramId, JTextField paramTitulo, JTextField paramAutor, JTextField paramAnio){
       
       setId(Integer.parseInt(paramId.getText()));
       setTitulo(paramTitulo.getText());
       setAutor(paramAutor.getText());
       setAnio(Integer.parseInt(paramAnio.getText())); 
       
       // Imprimir los valores obtenidos de los campos de texto
       System.out.println("Título: " + getTitulo());
       System.out.println("Autor: " + getAutor());
       System.out.println("Año: " + getAnio());
       
       Cconexion objetoConexion = new Cconexion();
       
       String consulta = "update libros set titulo = ?, autor = ?, anio = ? where libros.id=?;";
       
       try{
           
           CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
           cs.setString(1, getTitulo()); 
           cs.setString(2, getAutor());
           cs.setInt(3, getAnio()); 
           cs.setInt(4, getId());
           
           cs.execute();
           
           JOptionPane.showMessageDialog(null, "Se Modificó correctamente");
           
           // Después de insertar, actualiza la tabla
           MostrarLibros(paramTablaTotalLibros);
           
       }catch(Exception e){
           JOptionPane.showMessageDialog(null, "Error:"+e.toString());
       }
    }
      
    // Método para eliminar un libro de la base de datos
    public void EliminarLibro(JTable paramTablaTotalLibros, JTextField paramId){
       
        // Obtiene el ID del libro a eliminar y lo establece en el atributo del objeto
       setId(Integer.parseInt(paramId.getText()));
       
       // Imprimir los valores obtenidos de los campos de texto
       System.out.println("Título: " + getTitulo());
       System.out.println("Autor: " + getAutor());
       System.out.println("Año: " + getAnio());
       
       Cconexion objetoConexion = new Cconexion();
       
       String consulta = "delete from libros where libros.id=?;";
       
       try{
           
           CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
           cs.setInt(1, getId());
           
           cs.execute();
           
           JOptionPane.showMessageDialog(null, "Se Eliminó correctamente");
           
           // Después de insertar, actualiza la tabla
           MostrarLibros(paramTablaTotalLibros);
           
       }catch(Exception e){
           JOptionPane.showMessageDialog(null, "Error:"+e.toString());
       }
   
   }
    
}