
package com.mycompany.gestionbiblioteca;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 * Clase para establecer una conexión a una base de datos PostgreSQL.
 * @author Michell Alexis Policarpio Moran - zs21002379 - Diseño de APlicaciones Web NRC: 17479
 */
public class Cconexion {
    
    Connection conectar = null;
    
    // Definición de los parámetros de conexión
    String usuario = "postgres";
    String contrasenia = "Mapm2002";
    String bd = "bdbiblioteca";
    String ip = "localhost";
    String puerto = "5432";
    
    
    String cadena = "jdbc:postgresql://"+ip+":"+puerto+"/"+bd;
    
    
    //Método para establecer la conexión a la base de datos.
    public Connection establecerConexion(){
    
        try {
            // Carga del controlador de PostgreSQL
            Class.forName("org.postgresql.Driver");
            
            // Establecimiento de la conexión utilizando los parámetros especificados
            conectar = DriverManager.getConnection(cadena,usuario,contrasenia);
            
            // Mensaje de éxito en caso de conexión establecida
            //JOptionPane.showMessageDialog(null,"Se conectó correctamente a la base de datos");
            
            
        } catch (Exception e){
            // Manejo de excepciones en caso de error durante la conexión
            JOptionPane.showMessageDialog(null,"ERROR: "+e.toString());
        }
        
        return conectar;
    }
}
