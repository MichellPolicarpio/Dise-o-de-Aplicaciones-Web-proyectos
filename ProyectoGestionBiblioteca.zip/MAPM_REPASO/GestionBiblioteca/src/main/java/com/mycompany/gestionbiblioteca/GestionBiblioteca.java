
package com.mycompany.gestionbiblioteca;

/**
 * Clase principal que contiene el método main para iniciar el programa de gestión de biblioteca.
 * @author Michell Alexis Policarpio Moran - zs21002379 - Diseño de APlicaciones Web NRC: 17479
 */
public class GestionBiblioteca {

    public static void main(String[] args) {
        
        Menu objetoMenu = new Menu();  // Creación de un objeto de la clase Menu
        objetoMenu.setVisible(true); // Hacer visible el menú de la biblioteca
        
        
    }
}
