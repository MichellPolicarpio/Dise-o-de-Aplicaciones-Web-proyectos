package com.mycompany.gestionbiblioteca;

import java.sql.CallableStatement;
import javax.swing.JTextField;
import java.sql.ResultSet; 
import java.sql.Statement; 
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable; 
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

/**
 * 
 * @author Michell Alexis Policarpio Moran - zs21002379 - Diseño de APlicaciones Web NRC: 17479
 */

public class Clientes {
    
    int id;
    String nombre;
    String apellidoP;
    String apellidoM;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoP() {
        return apellidoP;
    }

    public void setApellidoP(String apellidoP) {
        this.apellidoP = apellidoP;
    }

    public String getApellidoM() {
        return apellidoM;
    }

    public void setApellidoM(String apellidoM) {
        this.apellidoM = apellidoM;
    }
    
    
   public void MostrarClientes(JTable paramTablaClientes){
   
       Cconexion objetoConexion = new Cconexion();
   
       DefaultTableModel modelo = new DefaultTableModel();
  
       String sql = "";
   
       modelo.addColumn("id");
       modelo.addColumn("nombre");
       modelo.addColumn("apellidoP");
       modelo.addColumn("apellidoM");
   
       paramTablaClientes.setModel(modelo);
   
       // Estableciendo el modo de selección de la tabla
       paramTablaClientes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
   
       sql = "SELECT * FROM clientes";
   
       String [] datos = new String[4];
   
       Statement st;
   
       try{
       
           st= objetoConexion.establecerConexion().createStatement();
       
           ResultSet rs = st.executeQuery(sql);
       
           while (rs.next()){
       
               datos[0] = rs.getString(1);
               datos[1] = rs.getString(2);
               datos[2] = rs.getString(3);
               datos[3] = rs.getString(4);
           
               modelo.addRow(datos);
           }
       
           paramTablaClientes.setModel(modelo);
       
       } catch (Exception e){
       
           JOptionPane.showMessageDialog(null,"Error:"+e.toString());
    
       }
    
  }
    
   public void InsertarCliente(JTable paramTablaClientes, JTextField paramNombre, JTextField paramApellidoP, JTextField paramApellidoM){
       
       setNombre(paramNombre.getText());
       setApellidoP(paramApellidoP.getText());
       setApellidoM(paramApellidoM.getText());
       
       Cconexion objetoConexion = new Cconexion();
       
       String consulta = "INSERT INTO clientes (nombre, apellidoP, apellidoM) VALUES (?, ?, ?)";
       
       try{
           
           CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
           cs.setString(1, getNombre()); 
           cs.setString(2, getApellidoP()); 
           cs.setString(3, getApellidoM()); 
           
           cs.execute();
           
           JOptionPane.showMessageDialog(null, "Cliente insertado correctamente");
           
           // Después de insertar, actualiza la tabla
           MostrarClientes(paramTablaClientes);
           
       }catch(Exception e){
           JOptionPane.showMessageDialog(null, "Error:"+e.toString());
       }
   
   }
   
   public void SeleccionarCliente(JTable paramTablaClientes, JTextField paramId, JTextField paramNombre, JTextField paramApellidoP, JTextField paramApellidoM){
       
       try{
           
           int fila = paramTablaClientes.getSelectedRow();
           
           if(fila>=0){
               
               paramId.setText(paramTablaClientes.getValueAt(fila,0).toString());
               paramNombre.setText(paramTablaClientes.getValueAt(fila,1).toString());
               paramApellidoP.setText(paramTablaClientes.getValueAt(fila,2).toString());
               paramApellidoM.setText(paramTablaClientes.getValueAt(fila,3).toString());
           }
           else{
               JOptionPane.showMessageDialog(null, "Por favor, seleccione una fila.");
           }
           
       }catch(Exception e){
           JOptionPane.showMessageDialog(null, "Error:"+e.toString());
       }
   }

   public void ModificarCliente(JTable paramTablaClientes, JTextField paramId, JTextField paramNombre, JTextField paramApellidoP, JTextField paramApellidoM){
       
       setId(Integer.parseInt(paramId.getText()));
       setNombre(paramNombre.getText());
       setApellidoP(paramApellidoP.getText());
       setApellidoM(paramApellidoM.getText()); 
       
       Cconexion objetoConexion = new Cconexion();
       
       String consulta = "UPDATE clientes SET nombre=?, apellidoP=?, apellidoM=? WHERE id=?";
       
       try{
           
           CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
           cs.setString(1, getNombre()); 
           cs.setString(2, getApellidoP());
           cs.setString(3, getApellidoM()); 
           cs.setInt(4, getId());
           
           cs.execute();
           
           JOptionPane.showMessageDialog(null, "Cliente modificado correctamente");
           
           // Después de insertar, actualiza la tabla
           MostrarClientes(paramTablaClientes);
           
       }catch(Exception e){
           JOptionPane.showMessageDialog(null, "Error:"+e.toString());
       }
   
   }
      
   public void EliminarCliente(JTable paramTablaClientes, JTextField paramId){
       
       setId(Integer.parseInt(paramId.getText()));
       
       Cconexion objetoConexion = new Cconexion();
       
       String consulta = "DELETE FROM clientes WHERE id=?";
       
       try{
           
           CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
           cs.setInt(1, getId());
           
           cs.execute();
           
           JOptionPane.showMessageDialog(null, "Cliente eliminado correctamente");
           
           // Después de insertar, actualiza la tabla
           MostrarClientes(paramTablaClientes);
           
       }catch(Exception e){
           JOptionPane.showMessageDialog(null, "Error:"+e.toString());
       }
   
   }
    
}